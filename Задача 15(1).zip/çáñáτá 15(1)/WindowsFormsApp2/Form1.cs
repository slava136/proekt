﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int s9 = 0;
            if (radioButton1.Checked == true)
            { s9 = 7; }
            if (radioButton2.Checked == true)
            { s9 = 14; }
            if (radioButton3.Checked == true)
            { s9 = 21; }

            string pub = textBox1.Text;
            int pub1 = Convert.ToInt32(pub);

            int itog = s9 * pub1;

            label3.Text = Convert.ToString(itog);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
