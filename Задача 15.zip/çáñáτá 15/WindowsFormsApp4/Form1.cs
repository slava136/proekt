﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a1 = 0;
            if (radioButton1.Checked == true)
            { a1 = 250; }
            if (radioButton2.Checked == true)
            { a1 = 500; }
            if (radioButton3.Checked == true)
            { a1 = 750; }

            string cs = textBox1.Text;

            int cs1 = Convert.ToInt32(cs);

            int itog = a1 * cs1;

            label3.Text = Convert.ToString(itog);
        }
    }
}
