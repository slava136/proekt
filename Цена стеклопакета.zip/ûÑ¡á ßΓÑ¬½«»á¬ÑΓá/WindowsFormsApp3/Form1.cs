﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int v = Convert.ToInt32(textBox1.Text);
            int s = Convert.ToInt32(textBox2.Text);
            double sum;
            double itog;
            sum = v * s + 10000;
            if (comboBox1.SelectedIndex == 0)
            {
                if (checkBox1.Checked)
                {
                    sum += 1000;
                }
                if (checkBox2.Checked)
                {
                    sum += 1000;
                }
                if (checkBox3.Checked)
                {
                    sum += 1000;
                }
                itog = sum;
                textBox3.Text = Convert.ToString(itog);
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                if (checkBox1.Checked)
                {
                    sum += 2000;
                }
                if (checkBox2.Checked)
                {
                    sum += 2000;
                }
                if (checkBox3.Checked)
                {
                    sum += 2000;
                }
                itog = sum;
                textBox3.Text = Convert.ToString(itog);
            }
        }
    }
}
